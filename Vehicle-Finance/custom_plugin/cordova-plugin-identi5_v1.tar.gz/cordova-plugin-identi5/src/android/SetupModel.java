package org.apache.cordova.device;

import android.os.Parcel;
import android.os.Parcelable;

import com.lillygen.api.Setup;

public class SetupModel  {
//
//    Setup setupGen;
//
//    boolean activate;
//
//    public SetupModel(Setup setup, boolean activate) {
//        this.setupGen = setup;
//        this.activate = activate;
//    }
//
//    public Setup getsetUp() {
//        return this.setupGen;
//    }
//
//    public  boolean getActivateflag() {
//        return this.activate;
//    }
//
//    @Override
//    public int describeContents() {
//        return 0;
//    }
//
//    @Override
//    public void writeToParcel(Parcel dest, int flags) {
//        dest.writeParcelable((Parcelable) setupGen, flags);
//
//    }
//
//    public SetupModel(Parcel source) {
//        age = source.readInt();
//        name = source.readString();
//        address = source.createStringArrayList();
//    }
//
//    public static final Creator<SetupModel> CREATOR = new Creator<SetupModel>() {
//        @Override
//        public SetupModel[] newArray(int size) {
//            return new SetupModel[size];
//        }
//
//        @Override
//        public SetupModel createFromParcel(Parcel source) {
//            return new SetupModel(source);
//        }
//    };
}
