import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './identity-details.component.html',
  styleUrls: ['./identity-details.component.css'],
})
export class IdentityDetailsComponent {}
