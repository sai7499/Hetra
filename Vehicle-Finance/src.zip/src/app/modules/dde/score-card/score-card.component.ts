import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: './score-card.component.html',
    styleUrls: ['./score-card.component.css']
})
export class ScoreCardComponent {
    constructor() {}
}
