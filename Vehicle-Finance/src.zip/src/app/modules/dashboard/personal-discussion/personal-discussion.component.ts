import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-discussion',
  templateUrl: './personal-discussion.component.html',
  styleUrls: ['./personal-discussion.component.css']
})
export class PersonalDiscussionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
