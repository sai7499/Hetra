import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-viability',
  templateUrl: './vehicle-viability.component.html',
  styleUrls: ['./vehicle-viability.component.css']
})
export class VehicleViabilityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
