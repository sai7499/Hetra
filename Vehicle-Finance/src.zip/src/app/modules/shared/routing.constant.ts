export const commonRoutingUrl = [
    { routeId: '2', routeUrl: '/pages/lead-creation', routingPage: 'Create New Lead'},
    { routeId: '21', routeUrl: '/pages/dashboard/leads-section/leads', routingPage: 'Go To New Leads Dashboard'},
    { routeId: '41', routeUrl: '/pages/dashboard/leads-section/leads', routingPage: 'Dashboard'},
    { routeId: '1', routeUrl: '/pages/', routingPage: 'Sample Page'},
    { routeId: '4', routeUrl: '/pages/', routingPage: 'Sample Page'},
    { routeId: '5', routeUrl: '/pages/', routingPage: 'Sample Page'},
];
