import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-only-modal',
  templateUrl: './text-only-modal.component.html',
  styleUrls: ['./text-only-modal.component.css']
})
export class TextOnlyModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
